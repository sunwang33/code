__author__ = "sun wang"
import package_test
package_test.test1.test()