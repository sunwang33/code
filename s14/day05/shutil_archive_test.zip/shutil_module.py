__author__ = "sun wang"
import shutil
# f1 = open("p_test.py",'r',encoding="utf-8")
# f2 = open("shutil测试",'w',encoding="utf-8")
# shutil.copyfileobj(f1,f2)
# shutil.copyfile("shutil测试1","shutil测试2")
# shutil.copystat("shutil测试1","shutil测试2")
# shutil.copytree("test4","new_test4")
# shutil.rmtree("new_test4")
shutil.make_archive("shutil_archive_test","zip","D:\git\s14\day05")
