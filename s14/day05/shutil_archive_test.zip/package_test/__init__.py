__author__ = "sun wang"
print('from the package package_test')

from . import test1
#import test1
