__author__ = "sun wang"
def test():
    print ("in the module")