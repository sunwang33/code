__author__ = "sun wang"
import module_test

def logger():
    module_test.test()

def search():
    module_test.test()
    print ('in the search')