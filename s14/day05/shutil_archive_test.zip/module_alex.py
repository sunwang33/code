__author__ = "sun wang"
name = "alex"
def say_hello():
    print ('hello alex')

def logger():
    print ("in the module alex")
def running():
    pass
